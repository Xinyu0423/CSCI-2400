This directory contains the code for building, solving, and distributing targets
for the Attack Lab

SUBDIRECTORIES:

	common

Code that gets used both for building and solving

	build

Code for constructing and distributing targets

	solve

Code for solving targets

	eval

Tools for examining submissions to checking adherence to guidelines

