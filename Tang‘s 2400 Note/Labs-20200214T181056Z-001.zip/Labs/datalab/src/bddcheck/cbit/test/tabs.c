int test_abs(int x) {
    return (x < 0) ? -x : x;
}
