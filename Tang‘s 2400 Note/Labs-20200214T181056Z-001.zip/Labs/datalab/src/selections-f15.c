//1
#include "bitXor.c"
#include "tmin.c"

//2
#include "isTmax.c"
#include "allOddBits.c"
#include "negate.c"

//3
#include "isAsciiDigit.c"
#include "conditional.c"
#include "isLessOrEqual.c"

//4
#include "logicalNeg.c"
#include "howManyBits.c"

//float
#include "float_twice.c"
#include "float_f2i.c"
#include "float_pwr2.c"
