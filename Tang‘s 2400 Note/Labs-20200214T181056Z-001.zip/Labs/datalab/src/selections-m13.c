#include "bitAnd.c"
#include "copyLSB.c"
#include "leastBitPos.c"
#include "logicalShift.c"
#include "bitCount.c"

#include "tmax.c"
#include "divpwr2.c"
#include "isNonNegative.c"
#include "isGreater.c"
#include "absVal.c"
#include "isPower2.c"

#include "float_i2f.c"
#include "float_abs.c"



