#include "isAsciiDigit.c"
#include "anyEvenBit.c"

#include "copyLSB.c"
#include "leastBitPos.c"
#include "divpwr2.c"

#include "conditional.c"
#include "isNonNegative.c"
#include "isGreater.c"

#include "absVal.c"
#include "isPower2.c"
#include "bitCount.c"

#include "float_neg.c"
#include "float_i2f.c"
