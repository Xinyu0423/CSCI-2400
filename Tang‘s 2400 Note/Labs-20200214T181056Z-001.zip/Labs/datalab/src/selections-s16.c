//1
#include "thirdBits.c"
#include "isTmin.c"

//2
#include "isNotEqual.c"
#include "anyOddBit.c"
#include "negate.c"

//3
#include "conditional.c"
#include "subOK.c"
#include "isGreater.c"

//4
#include "bitParity.c"
#include "howManyBits.c"

//float
#include "float_half.c"
#include "float_i2f.c"
#include "float_f2i.c"
